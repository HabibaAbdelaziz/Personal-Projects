package finalProject;

/**
 * Represents an audio book in the library.
 * Extends the LibraryItem class.
 */
class AudioBook extends LibraryItem {
    private int playTime;

    /**
     * Initializes an AudioBook object with the specified title, creator, publication year, and play time.
     *
     * @param title           the title of the audio book
     * @param creator         the creator of the audio book
     * @param publicationYear the publication year of the audio book
     * @param playTime        the play time of the audio book in minutes
     */
    public AudioBook(String title, String creator, int publicationYear, int playTime) {
        super(title, creator, publicationYear);
        this.playTime = playTime;
    }

    /**
     * Retrieves the play time of the audio book.
     *
     * @return the play time of the audio book in minutes
     */
    public int getPlayTime() {
        return playTime;
    }

    /**
     * Sets the play time of the audio book.
     *
     * @param playTime the play time of the audio book in minutes
     */
    public void setPlayTime(int playTime) {
        this.playTime = playTime;
    }

    /**
     * Retrieves the type of the library item.
     *
     * @return the type of the library item (AudioBook)
     */
    public String getType() {
        return "AudioBook";
    }

    /**
     * Returns a string representation of the AudioBook object.
     *
     * @return a string representation of the AudioBook object, including its title, creator, publication year,
     * and play time
     */
    @Override
    public String toString() {
        return super.toString() + ", Play Time: " + playTime;
    }

    /**
     * Displays the details of the audio book.
     * This method provides a specific implementation for displaying audio book details.
     */
    @Override
    public final void displayDetails() {
        // Specific implementation for displaying audio book details
        System.out.println("Audio Book: " + getTitle());
        System.out.println("Author: " + getCreator());
        System.out.println("Duration: " + playTime + " minutes");
    }
}
