package finalProject;

/**
 * Represents a CD in the library.
 * Extends the LibraryItem class.
 */
class CD extends LibraryItem {
    private String genre;

    /**
     * Initializes a CD object with the specified title, creator, publication year, and genre.
     *
     * @param title           the title of the CD
     * @param creator         the creator of the CD
     * @param publicationYear the publication year of the CD
     * @param genre           the genre of the CD
     */
    public CD(String title, String creator, int publicationYear, String genre) {
        super(title, creator, publicationYear);
        this.genre = genre;
    }

    /**
     * Retrieves the genre of the CD.
     *
     * @return the genre of the CD
     */
    public String getGenre() {
        return genre;
    }

    /**
     * Sets the genre of the CD.
     *
     * @param genre the genre of the CD
     */
    public void setGenre(String genre) {
        this.genre = genre;
    }

    /**
     * Retrieves the type of the library item.
     *
     * @return the type of the library item (CD)
     */
    public String getType() {
        return "CD";
    }

    /**
     * Returns a string representation of the CD object.
     *
     * @return a string representation of the CD object, including its title, creator, publication year,
     * and genre
     */
    @Override
    public String toString() {
        return super.toString() + ", Genre: " + genre;
    }

    /**
     * Displays the details of the CD.
     * This method provides a specific implementation for displaying CD details.
     */
    @Override
    public final void displayDetails() {
        // Specific implementation for displaying CD details
        System.out.println("CD: " + getTitle());
        System.out.println("Artist: " + getCreator());
        System.out.println("Genre: " + genre);
    }
}
