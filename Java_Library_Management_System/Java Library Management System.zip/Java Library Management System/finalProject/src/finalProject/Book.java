package finalProject;

import java.io.Serializable;

/**
 * Represents a book in the library.
 * Extends the LibraryItem class and implements the Serializable interface.
 */
class Book extends LibraryItem implements Serializable {
    private int numberOfPages;

    /**
     * Initializes a Book object with the specified title, creator, publication year, and number of pages.
     *
     * @param title           the title of the book
     * @param creator         the creator of the book
     * @param publicationYear the publication year of the book
     * @param numberOfPages   the number of pages in the book
     */
    public Book(String title, String creator, int publicationYear, int numberOfPages) {
        super(title, creator, publicationYear);
        this.numberOfPages = numberOfPages;
    }

    /**
     * Retrieves the number of pages in the book.
     *
     * @return the number of pages in the book
     */
    public int getNumberOfPages() {
        return numberOfPages;
    }

    /**
     * Sets the number of pages in the book.
     *
     * @param numberOfPages the number of pages in the book
     */
    public void setNumberOfPages(int numberOfPages) {
        this.numberOfPages = numberOfPages;
    }

    /**
     * Returns a string representation of the Book object.
     *
     * @return a string representation of the Book object, including its title, creator, publication year,
     * and number of pages
     */
    @Override
    public String toString() {
        return super.toString() + ", Number of Pages: " + numberOfPages;
    }

    /**
     * Retrieves the type of the library item.
     *
     * @return the type of the library item (Book)
     */
    public String getType() {
        return "Book";
    }

    /**
     * Displays the details of the book.
     * This method provides a specific implementation for displaying book details.
     */
    @Override
    public final void displayDetails() {
        // Specific implementation for displaying book details
        System.out.println("Book: " + getTitle());
        System.out.println("Author: " + getCreator());
        System.out.println("Page Count: " + numberOfPages);
    }
}
