package finalProject;

import java.io.Serializable;

/**
 * The abstract class representing a library item.
 */
abstract class LibraryItem implements Serializable {
    private String title;
    private String creator;
    private int publicationYear;
    private boolean isAvailable;
    private String borrowingUser;

    /**
     * Constructor for the LibraryItem class.
     *
     * @param title           The title of the library item.
     * @param creator         The creator of the library item.
     * @param publicationYear The publication year of the library item.
     */
    public LibraryItem(String title, String creator, int publicationYear) {
        this.title = title;
        this.creator = creator;
        this.publicationYear = publicationYear;
        this.isAvailable = true;
        this.borrowingUser = "";
    }

    /**
     * Getter for the title of the library item.
     *
     * @return The title of the library item.
     */
    public String getTitle() {
        return title;
    }

    /**
     * Getter for the creator of the library item.
     *
     * @return The creator of the library item.
     */
    public String getCreator() {
        return creator;
    }

    /**
     * Getter for the publication year of the library item.
     *
     * @return The publication year of the library item.
     */
    public int getPublicationYear() {
        return publicationYear;
    }

    /**
     * Getter for the availability of the library item.
     *
     * @return True if the library item is available, false otherwise.
     */
    public boolean isAvailable() {
        return isAvailable;
    }

    /**
     * Setter for the availability of the library item.
     *
     * @param available The availability status of the library item.
     */
    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    /**
     * Getter for the borrowing user of the library item.
     *
     * @return The borrowing user of the library item.
     */
    public String getBorrowingUser() {
        return borrowingUser;
    }

    /**
     * Setter for the borrowing user of the library item.
     *
     * @param borrowingUser The borrowing user of the library item.
     */
    public void setBorrowingUser(String borrowingUser) {
        this.borrowingUser = borrowingUser;
    }

    /**
     * Returns a string representation of the library item.
     *
     * @return The string representation of the library item.
     */
    @Override
    public String toString() {
        return "Title: " + title + ", Creator: " + creator + ", Publication Year: " + publicationYear +
                ", Available: " + isAvailable + ", Borrowing User: " + borrowingUser;
    }

    /**
     * Abstract method to get the type of the library item.
     *
     * @return The type of the library item.
     */
    public abstract String getType();

    /**
     * Abstract method to display the details of the library item.
     */
    public abstract void displayDetails();
}
