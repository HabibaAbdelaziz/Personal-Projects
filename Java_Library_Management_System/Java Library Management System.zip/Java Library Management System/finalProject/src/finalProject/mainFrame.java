package finalProject;

import javax.swing.*;
import java.awt.*;

public class mainFrame extends JFrame {
	
	public mainFrame() {
		// Constructor for the mainFrame class
		// Add any necessary initialization code here
	}
	
	// Existing code for your mainFrame class
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// Create and display the login page
				LoginPage loginPage = new LoginPage();
				loginPage.setVisible(true);
			}
		});
	}
}
