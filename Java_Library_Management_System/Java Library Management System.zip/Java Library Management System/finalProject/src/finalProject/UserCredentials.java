package finalProject;

public class UserCredentials {
    private String username;
    private String password;
    private boolean isLibrarian;

    public UserCredentials(String username, String password, boolean isLibrarian) {
        // Constructor for the UserCredentials class
        // Initialize the username, password, and isLibrarian fields
        this.username = username;
        this.password = password;
        this.isLibrarian = isLibrarian;
    }

    public String getUsername() {
        // Get the username
        return username;
    }

    public String getPassword() {
        // Get the password
        return password;
    }

    public boolean isLibrarian() {
        // Check if the user is a librarian
        return isLibrarian;
    }
}
