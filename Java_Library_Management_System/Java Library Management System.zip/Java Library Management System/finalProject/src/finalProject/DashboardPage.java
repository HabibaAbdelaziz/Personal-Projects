package finalProject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents the Dashboard page of the library management system.
 */
public class DashboardPage extends JFrame {

    private JButton addLibraryItemButton;
    private JButton borrowLibraryItemButton;
    private JButton returnLibraryItemButton;
    private JButton userManagementButton;
    private JButton generateReportsButton;
    private JButton searchLibraryItemButton;
    private String username;
    private boolean isLibrarian;
    private List<LibraryItem> libraryItems; // Array to store library items
    private final Object lock = new Object(); // Object for synchronization

    /**
     * Creates a new DashboardPage instance.
     *
     * @param username     the username of the logged-in user
     * @param isLibrarian  indicates whether the user is a librarian or not
     */
    public DashboardPage(String username, boolean isLibrarian) {
        this.username = username;
        this.isLibrarian = isLibrarian;

        // Load library items from file
        libraryItems = readLibraryItemsFromFile();

        setTitle("Dashboard");
        setSize(400, 200);
        setLayout(new GridLayout(3, 2));

        addLibraryItemButton = new JButton("Add Library Item");
        addLibraryItemButton.setEnabled(isLibrarian);
        add(addLibraryItemButton);

        borrowLibraryItemButton = new JButton("Borrow Library Item");
        add(borrowLibraryItemButton);

        returnLibraryItemButton = new JButton("Return Library Item");
        add(returnLibraryItemButton);

        userManagementButton = new JButton("User Management");
        userManagementButton.setEnabled(isLibrarian);
        add(userManagementButton);

        generateReportsButton = new JButton("Generate Reports");
        generateReportsButton.setEnabled(isLibrarian);
        add(generateReportsButton);

        searchLibraryItemButton = new JButton("Search Library Item");
        add(searchLibraryItemButton);

        // Load library items from file
        synchronized (lock) {
            libraryItems = readLibraryItemsFromFile();
        }

        // ActionListener for addLibraryItemButton
        addLibraryItemButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openAddLibraryItemWindow(); // Open the add library item window
            }
        });

        // ActionListener for borrowLibraryItemButton
        borrowLibraryItemButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openBorrowLibraryItemWindow(); // Open the borrow library item window
            }
        });

        // ActionListener for returnLibraryItemButton
        returnLibraryItemButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openReturnLibraryItemWindow(); // Open the return library item window
            }
        });

        // ActionListener for userManagementButton
        userManagementButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openUserManagementWindow(); // Open the user management window
            }
        });

        // ActionListener for searchLibraryItemButton
        searchLibraryItemButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openSearchLibraryItemWindow(); // Open the search library item window
            }
        });

        // ActionListener for generateReportsButton
        generateReportsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                List<LibraryItem> libraryItems = getAllLibraryItems();
                StringBuilder reportBuilder = new StringBuilder();

                if (libraryItems.isEmpty()) {
                    reportBuilder.append("No library items found.");
                } else {
                    for (LibraryItem libraryItem : libraryItems) {
                        reportBuilder.append("Title: ").append(libraryItem.getTitle()).append("\n");
                        reportBuilder.append("Author: ").append(libraryItem.getCreator()).append("\n");
                        reportBuilder.append("Year: ").append(libraryItem.getPublicationYear()).append("\n");
                        
                        // Check if the library item is an AudioBook
                        if (libraryItem instanceof AudioBook) {
                            AudioBook audioBook = (AudioBook) libraryItem;
                            reportBuilder.append("Play Time: ").append(audioBook.getPlayTime()).append("\n");
                        }
                        
                        // Check if the library item is an Book
                        if (libraryItem instanceof Book) {
                            Book Book = (Book) libraryItem;
                            reportBuilder.append("Number of Pages: ").append(Book.getNumberOfPages()).append("\n");
                        }
                        
                        // Check if the library item is an CD
                        if (libraryItem instanceof CD) {
                            CD CD = (CD) libraryItem;
                            reportBuilder.append("Genre: ").append(CD.getGenre()).append("\n");
                        }
                        
                        //Check if library item is available to borrow
                        if(!libraryItem.isAvailable()) {
                            reportBuilder.append("Is Available to borrow: No").append("\n");
                            reportBuilder.append("Borrower: ").append(libraryItem.getBorrowingUser()).append("\n");
                        }else {
                        	reportBuilder.append("Is Available to borrow: Yes").append("\n");
                        }
                        reportBuilder.append("\n");
                    }
                }
                JOptionPane.showMessageDialog(null, reportBuilder.toString(), "Library Reports", JOptionPane.INFORMATION_MESSAGE);
            }
        });


        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    

    
    /**
     * Retrieves a list of all library items.
     *
     * @return a list of all library items
     */
    private synchronized List<LibraryItem> getAllLibraryItems() {
        // Read the library items from the file
        synchronized (lock) {
            return readLibraryItemsFromFile();
        }
    }
    
    
    /**
     * Opens the AddLibraryItemWindow to add a new library item.
     */
    private synchronized void openAddLibraryItemWindow() {
        // Create a new JFrame for the Add Library Item window
        JFrame addLibraryItemFrame = new JFrame("Add Library Item");
        addLibraryItemFrame.setLayout(new GridLayout(6, 2));

        // Add a label and a combo box for selecting the item type
        addLibraryItemFrame.add(new JLabel("Type:"));
        String[] types = { "Book", "Audio Book", "CD" };
        JComboBox<String> typeComboBox = new JComboBox<>(types);
        addLibraryItemFrame.add(typeComboBox);

        // Add a label and a text field for entering the title
        addLibraryItemFrame.add(new JLabel("Title:"));
        JTextField titleField = new JTextField();
        addLibraryItemFrame.add(titleField);

        // Add a label and a text field for entering the creator
        addLibraryItemFrame.add(new JLabel("Creator:"));
        JTextField creatorField = new JTextField();
        addLibraryItemFrame.add(creatorField);

        // Add a label and a text field for entering the publication year
        addLibraryItemFrame.add(new JLabel("Publication Year:"));
        JTextField publicationYearField = new JTextField();
        addLibraryItemFrame.add(publicationYearField);

        // Add a label and a text field for entering additional information
        addLibraryItemFrame.add(new JLabel("Number of Pages / Play Time / Genre:"));
        JTextField additionalInfoField = new JTextField();
        addLibraryItemFrame.add(additionalInfoField);

        // Add a save button with an ActionListener to handle the click event
        JButton saveButton = new JButton("Save");
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Retrieve the selected item type, title, creator, and publication year
                String type = (String) typeComboBox.getSelectedItem();
                String title = titleField.getText();
                String creator = creatorField.getText();
                int publicationYear;
                try {
                    publicationYear = Integer.parseInt(publicationYearField.getText());
                } catch (NumberFormatException ex) {
                    // Display an error message for an invalid publication year
                    JOptionPane.showMessageDialog(addLibraryItemFrame, "Invalid publication year.");
                    return;
                }
                String additionalInfo = additionalInfoField.getText();

                LibraryItem libraryItem;
                if (type.equals("Book")) {
                    // For a book, retrieve the number of pages and create a Book object
                    int numberOfPages;
                    try {
                        numberOfPages = Integer.parseInt(additionalInfo);
                    } catch (NumberFormatException ex) {
                        // Display an error message for an invalid number of pages
                        JOptionPane.showMessageDialog(addLibraryItemFrame, "Invalid number of pages.");
                        return;
                    }
                    libraryItem = new Book(title, creator, publicationYear, numberOfPages);
                } else if (type.equals("Audio Book")) {
                    // For an audio book, retrieve the play time and create an AudioBook object
                    int playTime;
                    try {
                        playTime = Integer.parseInt(additionalInfo);
                    } catch (NumberFormatException ex) {
                        // Display an error message for an invalid play time
                        JOptionPane.showMessageDialog(addLibraryItemFrame, "Invalid play time.");
                        return;
                    }
                    libraryItem = new AudioBook(title, creator, publicationYear, playTime);
                } else if (type.equals("CD")) {
                    // For a CD, retrieve the genre and create a CD object
                    String genre = additionalInfo;
                    libraryItem = new CD(title, creator, publicationYear, genre);
                } else {
                    // Display an error message for an invalid item type
                    JOptionPane.showMessageDialog(addLibraryItemFrame, "Invalid item type.");
                    return;
                }

                // Add the new library item to the list
                libraryItems.add(libraryItem);
                // Update the library items file
                writeLibraryItemsToFile();

                // Display a success message
                JOptionPane.showMessageDialog(addLibraryItemFrame, "Library item added successfully!");

                // Dispose of the Add Library Item window
                addLibraryItemFrame.dispose();
            }
        });
        addLibraryItemFrame.add(saveButton);

        // Pack and display the Add Library Item window
        addLibraryItemFrame.pack();
        addLibraryItemFrame.setLocationRelativeTo(null);
        addLibraryItemFrame.setVisible(true);
    }
    
    
    
    /**
     * Opens the BorrowLibraryItemWindow to borrow a library item.
     */
    private synchronized void openBorrowLibraryItemWindow() {
        // Create a new JFrame for the Borrow Library Item window
        JFrame borrowLibraryItemFrame = new JFrame("Borrow Library Item");
        borrowLibraryItemFrame.setLayout(new GridLayout(2, 1));

        // Add a label and a text field for entering the title of the item to be borrowed
        JTextField titleField = new JTextField();
        borrowLibraryItemFrame.add(new JLabel("Title:"));
        borrowLibraryItemFrame.add(titleField);

        // Add a borrow button with an ActionListener to handle the click event
        JButton borrowButton = new JButton("Borrow");
        borrowButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Retrieve the title entered by the user
                String title = titleField.getText();

                // Find the library item by its title
                LibraryItem libraryItem = findLibraryItemByTitle(title);
                if (libraryItem == null) {
                    // Display an error message if the library item is not found
                    JOptionPane.showMessageDialog(borrowLibraryItemFrame, "Library item not found.");
                    return;
                }

                // Check if the library item is currently available for borrowing
                if (!libraryItem.isAvailable()) {
                    // Display an error message if the library item is already borrowed by another user
                    JOptionPane.showMessageDialog(borrowLibraryItemFrame, "Another user is currently borrowing this item.");
                    return;
                }

                // Set the library item as unavailable and assign the current user as the borrower
                libraryItem.setAvailable(false);
                libraryItem.setBorrowingUser(username);

                // Update the library items file
                writeLibraryItemsToFile();

                // Display a success message
                JOptionPane.showMessageDialog(borrowLibraryItemFrame, "You have successfully borrowed the library item.");

                // Dispose of the Borrow Library Item window
                borrowLibraryItemFrame.dispose();
            }
        });

        borrowLibraryItemFrame.add(borrowButton);

        // Pack and display the Borrow Library Item window
        borrowLibraryItemFrame.pack();
        borrowLibraryItemFrame.setLocationRelativeTo(null);
        borrowLibraryItemFrame.setVisible(true);
    }

    

     
    /**
     * Opens the ReturnLibraryItemWindow to return a borrowed library item.
     */
    private synchronized void openReturnLibraryItemWindow() {
        // Create a new JFrame for the Return Library Item window
        JFrame returnLibraryItemFrame = new JFrame("Return Library Item");
        returnLibraryItemFrame.setLayout(new GridLayout(2, 1));

        // Create a label to indicate the contents of the borrowed items text area
        JLabel borrowedItemsLabel = new JLabel("Borrowed Items:");
        returnLibraryItemFrame.add(borrowedItemsLabel, BorderLayout.NORTH);

        // Create a text area to display the library items currently borrowed by the user
        JTextArea borrowedItemsTextArea = new JTextArea();
        borrowedItemsTextArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(borrowedItemsTextArea);
        returnLibraryItemFrame.add(scrollPane);

        // Populate the text area with the titles of the library items currently borrowed by the user
        StringBuilder itemsText = new StringBuilder();
        for (LibraryItem libraryItem : libraryItems) {
            if (!libraryItem.isAvailable() && libraryItem.getBorrowingUser().equals(username)) {
                itemsText.append(libraryItem.getTitle()).append("\n");
            }
        }
        borrowedItemsTextArea.setText(itemsText.toString());

        // Add a text field for entering the title of the item to be returned
        JTextField titleField = new JTextField();
        returnLibraryItemFrame.add(titleField);

        // Add a return button with an ActionListener to handle the click event
        JButton returnButton = new JButton("Return");
        returnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Retrieve the title entered by the user
                String title = titleField.getText();

                // Find the library item by its title and borrowing user
                LibraryItem libraryItem = findLibraryItemByTitleAndBorrowingUser(title, username);
                if (libraryItem == null) {
                    // Display an error message if the library item is not found or not borrowed by the user
                    JOptionPane.showMessageDialog(returnLibraryItemFrame, "Library item not found or not borrowed by you.");
                    return;
                }

                // Set the library item as available and remove the borrowing user
                libraryItem.setAvailable(true);
                libraryItem.setBorrowingUser("");

                // Update the library items file
                writeLibraryItemsToFile();

                // Display a success message
                JOptionPane.showMessageDialog(returnLibraryItemFrame, "You have successfully returned the library item.");

                // Dispose of the Return Library Item window
                returnLibraryItemFrame.dispose();
            }
        });

        returnLibraryItemFrame.add(returnButton);

        // Pack and display the Return Library Item window
        returnLibraryItemFrame.pack();
        returnLibraryItemFrame.setLocationRelativeTo(null);
        returnLibraryItemFrame.setVisible(true);
    }




    /**
     * Opens the UserManagementWindow to manage user accounts.
     */
    private synchronized void openUserManagementWindow() {
        // Create a new JFrame for the User Management window
        JFrame userManagementFrame = new JFrame("User Management");
        userManagementFrame.setLayout(new BorderLayout());

        // Create a JTextArea to display the list of users
        JTextArea usersTextArea = new JTextArea();
        usersTextArea.setEditable(false);
        usersTextArea.setFont(new Font("Courier New", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(usersTextArea);
        userManagementFrame.add(scrollPane, BorderLayout.CENTER);

        // Create a JPanel for the button panel
        JPanel buttonPanel = new JPanel();

        // Add a button to open the Add User window
        JButton addUserButton = new JButton("Add User");
        addUserButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openAddUserWindow();
            }
        });
        buttonPanel.add(addUserButton);
        userManagementFrame.add(buttonPanel, BorderLayout.SOUTH);

        // Display the list of users in the text area
        List<UserCredentials> userCredentials = readCredentialsFromFile();
        StringBuilder sb = new StringBuilder();
        for (UserCredentials credentials : userCredentials) {
            sb.append("Username: ").append(credentials.getUsername());
            sb.append("\n");
            sb.append("Librarian: ").append(credentials.isLibrarian());
            sb.append("\n\n");
        }
        usersTextArea.setText(sb.toString());

        // Pack and display the User Management window
        userManagementFrame.pack();
        userManagementFrame.setLocationRelativeTo(null);
        userManagementFrame.setVisible(true);
    }



    /**
     * Opens the SearchLibraryItemWindow to search for a library item by title.
     */
    private synchronized void openSearchLibraryItemWindow() {
        // Create a new JFrame for the Search Library Item window
        JFrame searchLibraryItemFrame = new JFrame("Search Library Item");
        searchLibraryItemFrame.setLayout(new GridLayout(2, 1));

        // Create a JTextField for the user to enter the title
        JTextField titleField = new JTextField();
        searchLibraryItemFrame.add(new JLabel("Title:"));
        searchLibraryItemFrame.add(titleField);

        // Create a JButton for the search operation
        JButton searchButton = new JButton("Search");
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String title = titleField.getText();

                // Create a new thread for the search operation
                Thread searchThread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        // Search for the library item by title
                        LibraryItem libraryItem = findLibraryItemByTitle(title);
                        if (libraryItem == null) {
                            JOptionPane.showMessageDialog(searchLibraryItemFrame, "Library item not found.");
                        } else {
                            // Display the details of the found library item
                            StringBuilder itemDetails = new StringBuilder();
                            itemDetails.append("Title: ").append(libraryItem.getTitle()).append("\n");
                            itemDetails.append("Creator: ").append(libraryItem.getCreator()).append("\n");
                            itemDetails.append("Publication Year: ").append(libraryItem.getPublicationYear()).append("\n");
                            itemDetails.append("Type: ").append(libraryItem.getType()).append("\n");
                            itemDetails.append("Available: ").append(libraryItem.isAvailable()).append("\n");
                            if (!libraryItem.isAvailable()) {
                                itemDetails.append("Borrowing User: ").append(libraryItem.getBorrowingUser()).append("\n");
                            }
                            JOptionPane.showMessageDialog(searchLibraryItemFrame, itemDetails.toString());
                        }

                        // Close the search window
                        searchLibraryItemFrame.dispose();
                    }
                });

                // Start the search thread
                searchThread.start();
            }
        });

        searchLibraryItemFrame.add(searchButton);

        // Pack and display the Search Library Item window
        searchLibraryItemFrame.pack();
        searchLibraryItemFrame.setLocationRelativeTo(null);
        searchLibraryItemFrame.setVisible(true);
    }



    
    /**
     * Reads library items from a file and returns a list of library items.
     *
     * @return The list of library items read from the file.
     */
    private synchronized List<LibraryItem> readLibraryItemsFromFile() {
        List<LibraryItem> items = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader("libraryItems.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Split the line by commas to extract the item details
                String[] parts = line.split(",");
                String type = parts[0];
                String title = parts[1];
                String creator = parts[2];
                int publicationYear = Integer.parseInt(parts[3]);
                boolean isAvailable = Boolean.parseBoolean(parts[4]);
                String borrowingUser = parts[5];

                LibraryItem libraryItem;
                switch (type) {
                    case "Book":
                        // Extract the additional book-specific information
                        int numberOfPages = Integer.parseInt(parts[6]);
                        libraryItem = new Book(title, creator, publicationYear, numberOfPages);
                        break;
                    case "AudioBook":
                        // Extract the additional audio book-specific information
                        int playTime = Integer.parseInt(parts[6]);
                        libraryItem = new AudioBook(title, creator, publicationYear, playTime);
                        break;
                    case "CD":
                        // Extract the additional CD-specific information
                        String genre = parts[6];
                        libraryItem = new CD(title, creator, publicationYear, genre);
                        break;
                    default:
                        // Skip the line if the item type is unknown
                        continue;
                }

                // Set the availability and borrowing user of the library item
                libraryItem.setAvailable(isAvailable);
                libraryItem.setBorrowingUser(borrowingUser);
                items.add(libraryItem);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return items;
    }

    
    /**
     * Writes the library items to a file.
     */
    private synchronized void writeLibraryItemsToFile() {
        synchronized (lock) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("libraryItems.txt"))) {
                for (LibraryItem libraryItem : libraryItems) {
                    String type = libraryItem.getType();
                    String title = libraryItem.getTitle();
                    String creator = libraryItem.getCreator();
                    int publicationYear = libraryItem.getPublicationYear();
                    boolean isAvailable = libraryItem.isAvailable();
                    String borrowingUser = libraryItem.getBorrowingUser();

                    StringBuilder line = new StringBuilder();
                    line.append(type).append(",");
                    line.append(title).append(",");
                    line.append(creator).append(",");
                    line.append(publicationYear).append(",");
                    line.append(isAvailable).append(",");
                    line.append(borrowingUser).append(",");

                    // Append additional information specific to each item type
                    if (libraryItem instanceof Book) {
                        Book book = (Book) libraryItem;
                        line.append(book.getNumberOfPages());
                    } else if (libraryItem instanceof AudioBook) {
                        AudioBook audioBook = (AudioBook) libraryItem;
                        line.append(audioBook.getPlayTime());
                    } else if (libraryItem instanceof CD) {
                        CD cd = (CD) libraryItem;
                        line.append(cd.getGenre());
                    }

                    writer.write(line.toString());
                    writer.newLine();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    /**
     * Finds a library item by its title.
     *
     * @param title the title of the library item to search for
     * @return the found library item, or null if not found
     */
    private LibraryItem findLibraryItemByTitle(String title) {
        for (LibraryItem libraryItem : libraryItems) {
            if (libraryItem.getTitle().equalsIgnoreCase(title)) {
                return libraryItem;
            }
        }
        return null;
    }


    /**
     * Finds a library item by its title and borrowing user.
     *
     * @param title         the title of the library item to search for
     * @param borrowingUser the borrowing user of the library item to search for
     * @return the found library item, or null if not found
     */
    private synchronized LibraryItem findLibraryItemByTitleAndBorrowingUser(String title, String borrowingUser) {
        for (LibraryItem libraryItem : libraryItems) {
            if (libraryItem.getTitle().equalsIgnoreCase(title) && libraryItem.getBorrowingUser().equalsIgnoreCase(borrowingUser)) {
                return libraryItem;
            }
        }
        return null;
    }



    /**
     * Opens the "Add User" window.
     * Allows the user to enter information for a new user and save it.
     */
    private synchronized void openAddUserWindow() {
        // Create the frame for the "Add User" window
        JFrame addUserFrame = new JFrame("Add User");
        addUserFrame.setLayout(new GridLayout(5, 2));

        // Create and add the components for entering user information
        addUserFrame.add(new JLabel("Username:"));
        JTextField usernameField = new JTextField();
        addUserFrame.add(usernameField);

        addUserFrame.add(new JLabel("Password:"));
        JPasswordField passwordField = new JPasswordField();
        addUserFrame.add(passwordField);

        addUserFrame.add(new JLabel("ID:"));
        JTextField idField = new JTextField();
        addUserFrame.add(idField);

        addUserFrame.add(new JLabel("Is Librarian:"));
        JCheckBox isLibrarianCheckBox = new JCheckBox();
        addUserFrame.add(isLibrarianCheckBox);

        // Create and add the "Save" button
        JButton saveButton = new JButton("Save");
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Retrieve the entered information
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                String id = idField.getText();
                boolean isLibrarian = isLibrarianCheckBox.isSelected();

                // Validate the entered information
                if (username.isEmpty() || password.isEmpty() || id.isEmpty()) {
                    JOptionPane.showMessageDialog(addUserFrame, "Please fill in all the fields.");
                    return;
                }

                // Create a new user credentials object
                UserCredentials newUserCredentials = new UserCredentials(username, password, isLibrarian);
                // Write the new user credentials to the file
                writeCredentialsToFile(newUserCredentials);

                // Display a success message and close the window
                JOptionPane.showMessageDialog(addUserFrame, "User added successfully!");
                addUserFrame.dispose();
            }
        });
        addUserFrame.add(saveButton);

        // Adjust the frame properties and make it visible
        addUserFrame.pack();
        addUserFrame.setLocationRelativeTo(null);
        addUserFrame.setVisible(true);
    }

	
    /**
     * Reads the user credentials from a file and returns a list of UserCredentials objects.
     *
     * @return A list of UserCredentials objects read from the file.
     */
    private synchronized List<UserCredentials> readCredentialsFromFile() {
        // Create a list to store the user credentials
        List<UserCredentials> userCredentials = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader("loginCredentials.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Split the line into parts using the comma as the delimiter
                String[] parts = line.split(",");
                if (parts.length == 3) {
                    // Extract the username, password, and isLibrarian values
                    String username = parts[0];
                    String password = parts[1];
                    boolean isLibrarian = Boolean.parseBoolean(parts[2]);

                    // Create a new UserCredentials object and add it to the list
                    UserCredentials credentials = new UserCredentials(username, password, isLibrarian);
                    userCredentials.add(credentials);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Return the list of user credentials
        return userCredentials;
    }

	
    /**
     * Writes the provided UserCredentials object to a file.
     *
     * @param userCredentials The UserCredentials object to write to the file.
     */
    private synchronized void writeCredentialsToFile(UserCredentials userCredentials) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("loginCredentials.txt", true))) {
            // Construct the line to write in the file by concatenating the username, password, and isLibrarian values
            String line = userCredentials.getUsername() + "," + userCredentials.getPassword() + "," + userCredentials.isLibrarian();
            
            // Write the line to the file and add a new line character
            writer.write(line);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    /**
     * The main method that serves as the entry point of the application.
     *
     * @param args The command line arguments (not used in this example).
     */
    public synchronized static void main(String[] args) {
        // Example usage
        
        // Create an instance of the DashboardPage class with an empty username and isLibrarian set to true
        DashboardPage dashboardPage = new DashboardPage("", true);
        
        // Set the visibility of the dashboard page to true, making it visible to the user
        dashboardPage.setVisible(true);
    }

}
