package finalProject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents the login page of the library application.
 */
public class LoginPage extends JFrame {

    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;

    /**
     * Constructor for the LoginPage class.
     */
    public LoginPage() {
        setTitle("Login");
        setSize(300, 150);
        setLayout(new GridLayout(3, 2));

        add(new JLabel("Username:"));
        usernameField = new JTextField();
        add(usernameField);

        add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        add(passwordField);

        loginButton = new JButton("Login");
        add(loginButton);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());

                // Validate login credentials
                if (validateLogin(username, password)) {
                    // Successful login
                    JOptionPane.showMessageDialog(LoginPage.this, "Login successful!");

                    // Determine user role
                    boolean isLibrarian = isUserLibrarian(username);

                    // Create and show the dashboard/home page
                    DashboardPage dashboardPage = new DashboardPage(username, isLibrarian);
                    dashboardPage.setVisible(true);

                    // Close the login page (optional)
                    dispose();
                } else {
                    // Invalid login
                    JOptionPane.showMessageDialog(LoginPage.this, "Invalid username or password. Please enter credentials that are in the library database.");
                }
            }
        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    /**
     * Validates the login credentials.
     *
     * @param username The entered username.
     * @param password The entered password.
     * @return True if the login credentials are valid, false otherwise.
     */
    private boolean validateLogin(String username, String password) {
        List<UserCredentials> userCredentials = readCredentialsFromFile();

        for (UserCredentials credentials : userCredentials) {
            if (credentials.getUsername().equals(username) && credentials.getPassword().equals(password)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Checks if the user with the given username is a librarian.
     *
     * @param username The username of the user.
     * @return True if the user is a librarian, false otherwise.
     */
    private boolean isUserLibrarian(String username) {
        List<UserCredentials> userCredentials = readCredentialsFromFile();

        for (UserCredentials credentials : userCredentials) {
            if (credentials.getUsername().equals(username)) {
                return credentials.isLibrarian();
            }
        }

        return false;
    }

    /**
     * Reads the user credentials from a file.
     *
     * @return A list of UserCredentials read from the file.
     */
    private List<UserCredentials> readCredentialsFromFile() {
        List<UserCredentials> userCredentials = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader("loginCredentials.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3) {
                    String username = parts[0];
                    String password = parts[1];
                    boolean isLibrarian = Boolean.parseBoolean(parts[2]);

                    UserCredentials credentials = new UserCredentials(username, password, isLibrarian);
                    userCredentials.add(credentials);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return userCredentials;
    }

    /**
     * Writes the user credentials to a file.
     *
     * @param userCredentials The list of UserCredentials to be written to the file.
     */
    private void writeCredentialsToFile(List<UserCredentials> userCredentials) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("loginCredentials.txt"))) {
            for (UserCredentials credentials : userCredentials) {
                String line = credentials.getUsername() + "," + credentials.getPassword() + "," + credentials.isLibrarian();
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * The main method to start the application.
     *
     * @param args The command line arguments.
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                LoginPage loginPage = new LoginPage();
                loginPage.setVisible(true);
            }
        });
    }
}
