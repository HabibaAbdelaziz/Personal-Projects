package finalProject;

import java.io.Serializable;

/**
 * Represents a library user.
 */
class LibraryUser implements Serializable {
    private String username;
    private String password;
    private boolean isLibrarian;

    /**
     * Constructor for the LibraryUser class.
     *
     * @param username    The username of the library user.
     * @param password    The password of the library user.
     * @param isLibrarian Indicates if the user is a librarian or not.
     */
    public LibraryUser(String username, String password, boolean isLibrarian) {
        this.username = username;
        this.password = password;
        this.isLibrarian = isLibrarian;
    }

    /**
     * Getter for the username of the library user.
     *
     * @return The username of the library user.
     */
    public String getUsername() {
        return username;
    }

    /**
     * Getter for the password of the library user.
     *
     * @return The password of the library user.
     */
    public String getPassword() {
        return password;
    }

    /**
     * Checks if the library user is a librarian.
     *
     * @return True if the user is a librarian, false otherwise.
     */
    public boolean isLibrarian() {
        return isLibrarian;
    }

    /**
     * Returns a string representation of the library user.
     *
     * @return The string representation of the library user.
     */
    @Override
    public String toString() {
        return "Username: " + username + ", Password: " + password + ", Is Librarian: " + isLibrarian;
    }
}
