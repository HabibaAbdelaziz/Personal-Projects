import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.JTextArea;
import java.awt.Font;

public class MainFrame extends JFrame {

	private String state = "ENTER_PIN";
	private boolean isPinEntered = false;
	private BankAccount receiverAccount = null;
	private JPanel contentPane;
	private JLabel SKKUATMLabel;
	private JButton Option1Button;
	private JButton Option2Button;
	private JButton Option3Button;
	private JButton Option4Button;
	private JButton EnglishButton;
	private JButton KoreanButton;
	private JButton CancelButton;
	private JButton ClearButton;
	private JButton EnterButton;
	private JButton button2;
	private JButton button1;
	private JButton button3;
	private JButton button4;
	private JButton button5;
	private JButton button6;
	private JButton button7;
	private JButton button8;
	private JButton button9;
	private JButton button0;
	private JLabel WOORILabel;
	private JTextArea outputTextArea;
	private JLabel OutputLabel;
	private JLabel InputLabel;
	private JTextField inputTextField;
	int currentAccountIndex;
	private JLabel TestLabel1;
	private JLabel TestLabel2;
	private JLabel TestLabel3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrame frame = new MainFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
	}
	
	/**
	 * Checks if the entered PIN matches a valid user's PIN
	 * @param inputPin the PIN entered by the user
	 * @return the index of the matching user in the users array, or -1 if no match is found
	 */
	public int checkInputPin(String inputPin, ArrayList<BankAccount> accounts) {
		//Converting the String inputPin into integer form
		if(!inputPin.isEmpty()) {
			int integerPin = Integer.parseInt(inputPin);
			for(int i = 0; i < 3; i++) {
				BankAccount bufferAccount =  accounts.get(i);
				if(bufferAccount.getPinCode() == integerPin) {
					return i;
				}
			}
			return -1; 
		}else{
			return 0;
		}
	}
	
	
	
	
	
	/**
	 * Create the frame.
	 */
	public MainFrame() {
		
		ArrayList<BankAccount> accounts = new ArrayList<>();
		User user1 = new User("Firuz");
		User user2 = new User("John");
		User user3 = new User("Eldor");
		
		accounts.add(new BankAccount("200100237898", 1234, 500000.0, user1));
		accounts.add(new BankAccount("110000022033", 4321, 700000.0, user2));
		accounts.add(new BankAccount("111111111111", 2222, 900000.0, user3));
		
		
		
		

		
		setTitle("ATM");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 562, 591);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		SKKUATMLabel = new JLabel("SKKU ATM");
		SKKUATMLabel.setHorizontalAlignment(SwingConstants.CENTER);
		SKKUATMLabel.setBounds(178, 35, 127, 24);
		contentPane.add(SKKUATMLabel);
		
		Option1Button = new JButton("OPTION 1");
		Option1Button.setIcon(new ImageIcon(MainFrame.class.getResource("/icons/arr.png")));
		Option1Button.setBounds(10, 76, 113, 23);
		contentPane.add(Option1Button);
		
		Option2Button = new JButton("OPTION 2");
		Option2Button.setIcon(new ImageIcon(MainFrame.class.getResource("/icons/arr.png")));
		Option2Button.setBounds(10, 98, 113, 23);
		contentPane.add(Option2Button);
		
		Option3Button = new JButton("OPTION 3");
		Option3Button.setIcon(new ImageIcon(MainFrame.class.getResource("/icons/arr.png")));
		Option3Button.setBounds(10, 122, 113, 23);
		contentPane.add(Option3Button);
		
		Option4Button = new JButton("OPTION 4");
		Option4Button.setIcon(new ImageIcon(MainFrame.class.getResource("/icons/arr.png")));
		Option4Button.setBounds(10, 147, 113, 23);
		contentPane.add(Option4Button);
		
		EnglishButton = new JButton("ENGLISH");
		EnglishButton.setIcon(new ImageIcon(MainFrame.class.getResource("/icons/eng.png")));
		EnglishButton.setBounds(400, 76, 149, 23);
		contentPane.add(EnglishButton);
		
		KoreanButton = new JButton("KOREAN");
		KoreanButton.setIcon(new ImageIcon(MainFrame.class.getResource("/icons/kor.png")));
		KoreanButton.setBounds(400, 98, 149, 23);
		contentPane.add(KoreanButton);
		
		CancelButton = new JButton("CANCEL");
		CancelButton.setIcon(new ImageIcon(MainFrame.class.getResource("/icons/cancel.png")));
		CancelButton.setBounds(357, 256, 149, 71);
		contentPane.add(CancelButton);
		
		ClearButton = new JButton("CLEAR");
		ClearButton.setIcon(new ImageIcon(MainFrame.class.getResource("/icons/clear.png")));
		ClearButton.setBounds(357, 323, 149, 70);
		contentPane.add(ClearButton);
		
		 //state 0 means pin is being entered
		EnterButton = new JButton("ENTER");
		EnterButton.setIcon(new ImageIcon(MainFrame.class.getResource("/icons/enter.png")));
		EnterButton.setBounds(357, 392, 149, 70);
		contentPane.add(EnterButton);
		
		button1 = new JButton("");
		button1.setIcon(new ImageIcon(MainFrame.class.getResource("/icons/1.png")));
		button1.setBounds(133, 257, 73, 70);
		contentPane.add(button1);
		
		button2 = new JButton("");
		button2.setIcon(new ImageIcon(MainFrame.class.getResource("/icons/2.png")));
		button2.setBounds(205, 257, 73, 70);
		contentPane.add(button2);
		
		button3 = new JButton("");
		button3.setIcon(new ImageIcon(MainFrame.class.getResource("/icons/3.png")));
		button3.setBounds(274, 257, 73, 70);
		contentPane.add(button3);
		
		button4 = new JButton("");
		button4.setIcon(new ImageIcon(MainFrame.class.getResource("/icons/4.png")));
		button4.setBounds(134, 323, 73, 70);
		contentPane.add(button4);
		
		button5 = new JButton("");
		button5.setIcon(new ImageIcon(MainFrame.class.getResource("/icons/5.png")));
		button5.setBounds(205, 323, 73, 70);
		contentPane.add(button5);
		
		button6 = new JButton("");
		button6.setIcon(new ImageIcon(MainFrame.class.getResource("/icons/6.png")));
		button6.setBounds(274, 323, 73, 70);
		contentPane.add(button6);
		
		button7 = new JButton("");
		button7.setIcon(new ImageIcon(MainFrame.class.getResource("/icons/7.png")));
		button7.setBounds(133, 392, 73, 70);
		contentPane.add(button7);
		
		button8 = new JButton("");
		button8.setIcon(new ImageIcon(MainFrame.class.getResource("/icons/8.png")));
		button8.setBounds(204, 392, 73, 70);
		contentPane.add(button8);
		
		button9 = new JButton("");
		button9.setIcon(new ImageIcon(MainFrame.class.getResource("/icons/9.png")));
		button9.setBounds(273, 392, 73, 70);
		contentPane.add(button9);
		
		button0 = new JButton("");
		button0.setIcon(new ImageIcon(MainFrame.class.getResource("/icons/0.png")));
		button0.setBounds(205, 464, 73, 70);
		contentPane.add(button0);
		
		WOORILabel = new JLabel("");
		WOORILabel.setIcon(new ImageIcon(MainFrame.class.getResource("/icons/woori.png")));
		WOORILabel.setBounds(10, 11, 295, 34);
		contentPane.add(WOORILabel);
		
		outputTextArea = new JTextArea();
		outputTextArea.setFont(new Font("Monospaced", Font.BOLD, 12));
		outputTextArea.setEditable(false);
		outputTextArea.setBounds(123, 74, 267, 133);
		contentPane.add(outputTextArea);
		
		OutputLabel = new JLabel("Output Screen");
		OutputLabel.setBounds(123, 56, 106, 14);
		contentPane.add(OutputLabel);
		
		InputLabel = new JLabel("Input Screen");
		InputLabel.setBounds(123, 209, 84, 14);
		contentPane.add(InputLabel);
		
		inputTextField = new JTextField();
		inputTextField.setEditable(false);
		inputTextField.setBounds(123, 225, 192, 20);
		contentPane.add(inputTextField);
		inputTextField.setColumns(10);
		
		//Displayed as soon as the window starts
		outputTextArea.setText("Please insert your card\nand press enter");
		
		
		/*****actionEvents of Buttons*****/
		Option1Button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				inputTextField.setText("");
				outputTextArea.setText("User:"+ accounts.get(currentAccountIndex).getUser().getUserName()
											+"\nBalance:"+ accounts.get(currentAccountIndex).getBalance()+
											"\nPress ENTER...");
				//Updating state to next state
				state = "BALANCE_CHECKING";	
			}
		});
		
		
		Option2Button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				//Prompt user to enter withdrawal amount
				outputTextArea.setText("Enter amount to withdraw:");
				inputTextField.setText("");
				//Updating state to next state
				state = "WITHDRAW_OPTIONS";	
			}
		});
		
		Option3Button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				//Prompting user to enter deposit amount
				outputTextArea.setText("Enter Deposit Amount:");
				inputTextField.setText("");
				//Updating state to the next state
				state = "DEPOSIT_OPTIONS";
			}
		});
		
		Option4Button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				//Prompting user to enter receiver's bank account number
				inputTextField.setText("");
				outputTextArea.setText("Enter Account Number (Receiver):");
				//Updating state to the next state
				state = "TRANSFER_RECEIVER_ACCOUNT_INPUT";
			}
		});
		
		CancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Displaying message saying process is canceled.
				outputTextArea.setText("Process is canceled by user.\nPress ENTER....");
				//Clearing the input TextField
				inputTextField.setText("");	
				//Updating state to the next state
				state = "ENTER_PIN";
			}
		});
		
		ClearButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//Clearing input field
				inputTextField.setText("");	
			}
		});
		
	
		
		EnterButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				switch(state) {
					case "START":
						//Updating the state to the next state
						isPinEntered = true;
						state = "ENTER_PIN";
						break;
					case "ENTER_PIN":
						outputTextArea.setText("PIN:");
						String userInput = inputTextField.getText();
						boolean isInputPinValid = false;
						
						if(isPinEntered) {
							if(!userInput.isEmpty()) {
								/*If checkInputPin() returns -1, then the input pin is not valid. 
								 * Otherwise, it will return the index of the user that matched the entered in.*/
								currentAccountIndex = checkInputPin(userInput, accounts);
								if( currentAccountIndex != -1) { 
									isInputPinValid = true ;
								}
								if(isInputPinValid) { 
									//Update the state to the next state
									state = "ACCOUNT_OPTIONS";
								}else { //if input PIN is invalid
									outputTextArea.setText("Wrong Pin.Try again:\n");
									state = "ENTER_PIN";
									inputTextField.setText("");
								}
							}else {
								outputTextArea.setText("PIN: ");
								state = "ENTER_PIN";
							}
						}else {
							isPinEntered = true;
							state = "ENTER_PIN";
						}
						break;
					case "ACCOUNT_OPTIONS":
						inputTextField.setText("");
						//Get the user's selected account option
						outputTextArea.setText("Welcome "+ accounts.get(currentAccountIndex).getUser().getUserName()+
										"\nPlease choose options:\n"+
										"OPTION 1: Balance Checking\n"+
										"OPTION 2: Withdrawing money\n"+
										"OPTION 3: Deposit\n"+
										"OPTION 4: Transfer");
						break;
					case "BALANCE_CHECKING":
						inputTextField.setText("");
						outputTextArea.setText("Thank your for banking with us!"
								+ "\nPress ENTER...");
						
						state = "ENTER_PIN";
						break;
					case "WITHDRAW_OPTIONS":
						
						//Getting the user's withdrawal amount and converting it into int withdrawalUserInput
						int withdrawUserInput = Integer.parseInt(inputTextField.getText());
						//Converting the integer input to a double
						double withdrawalAmount = Double.parseDouble(String.valueOf(withdrawUserInput));
						
						//Check if withdrawal amount is less than or equal to account balance
						if(withdrawalAmount <= accounts.get(currentAccountIndex).getBalance()) {
							//Deduct withdrawal amount from the account balance
							accounts.get(currentAccountIndex).setBalance(accounts.get(currentAccountIndex).getBalance() - withdrawalAmount);
							
							//Updating outputTextArea
							outputTextArea.setText("Success:)\nUser: "+ accounts.get(currentAccountIndex).getUser().getUserName()
									+"\nWithdrawal Amount: " + withdrawalAmount
									+"\nCurrent Balance: "+ accounts.get(currentAccountIndex).getBalance()
									+"\nPress ENTER...");
							inputTextField.setText("");
							state = "ENTER_PIN";
						}else {
							//Updating output text Area with error message
							outputTextArea.setText("Not enough money!\nPress ENTER...");
							inputTextField.setText("");
							state = "ENTER_PIN";
						}
						//Changing state back to ACCOUNT_OPTIONS
						
						break;
					case "DEPOSIT_OPTIONS":
						//Getting the user's deposit amount and converting it into int depositUserInput
						int depositUserInput = Integer.parseInt(inputTextField.getText());
						//Converting the integer input to a double
						double depositAmount = Double.parseDouble(String.valueOf(depositUserInput));
					
						//Add deposit amount to the account balance
						accounts.get(currentAccountIndex).setBalance(accounts.get(currentAccountIndex).getBalance() + depositAmount);
						
						//Updating outputTextArea
						outputTextArea.setText("Success:)\nUser: "+ accounts.get(currentAccountIndex).getUser().getUserName()
								+"\nDeposit Amount: "+ depositAmount
								+"\nCurrent Balance: "+ accounts.get(currentAccountIndex).getBalance()
								+"\nPress ENTER...");
						//Clearing inputTextField
						inputTextField.setText("");
						//Changing state back to ACCOUNT_OPTIONS
						state = "ENTER_PIN";
					
						break;
					case "TRANSFER_RECEIVER_ACCOUNT_INPUT":
						//Creating a buffer account called receiverAccount so we can search for the receiver's information in the accounts Array List stored in the program.
						String receiverAccountNumber = inputTextField.getText();
						
						boolean foundReceiverAccount = false;
						
						
							
						//stores the index in accounts ArrayList that corresponds to receiverAccount
						 
						//Iterating through the accounts ArrayList to find bank account corresponding to receiver account
						for(int i=0; i<3; i++) {
							if(accounts.get(i).getBankNumber().equals(receiverAccountNumber)) {
								receiverAccount = accounts.get(i);
								foundReceiverAccount = true;
								state = "TRANSFER_AMOUNT_INPUT";
								inputTextField.setText("");
								outputTextArea.setText("Transfer Account: "+ receiverAccount.getUser().getUserName()
										+"\nEnter Transfer Amount:");
								break;
							}
						}	
						
						//Checking to see if the receiver account was found or not in the accounts ArrayList
						if(!foundReceiverAccount) {
							outputTextArea.setText("You entered the wrong account number!\nPress Enter...");
							inputTextField.setText("");
							state = "ENTER_PIN";
							break;	
						}
						//Updating state to the next state.
						
						break;
						
					case "TRANSFER_AMOUNT_INPUT": /*After prog check the user entered the correct receiver account,
						s/he will be prompted to enter the transfer amount in this state*/
						
						//Converting the integer input transferAmountInteger to a double called transferAmount
						double transferAmount = Double.parseDouble(inputTextField.getText());
						//Checking to see of sender has enough money to send the transfer amount
						if(transferAmount > accounts.get(currentAccountIndex).getBalance()) {
							outputTextArea.setText("Not enough Money.\nPress Enter...");
							state = "ENTER_PIN";
						}else {
							//Withdrawing from current account(sender) and depositing the amount in the receiverAccount
							accounts.get(currentAccountIndex).withdraw(transferAmount);
							receiverAccount.deposit(transferAmount);
							
							//Assigning the receiver Account to the corresponding bank account in the ArrayList
							for(int i = 0; i < 3; i++) {
								if(accounts.get(i).getBankNumber().equals(receiverAccount.getBankNumber())) {
									accounts.set(i, receiverAccount);
								}
							}
							
							//Output message when transfer is successful
							outputTextArea.setText("Transfer Amount:" + transferAmount 
													+"\nCurrent Balance: "+accounts.get(currentAccountIndex).getBalance()
													+"\nPress ENTER....");
							inputTextField.setText("");
						}
							state = "ENTER_PIN";
						break;
						
						
				}
			}	
		});
		
		button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				inputTextField.setText(inputTextField.getText()+ "1");
				
			}
		});
		
		button2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				inputTextField.setText(inputTextField.getText()+ "2");
			}
		});
		
		button3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { 
				inputTextField.setText(inputTextField.getText()+ "3");
			}
		});
		
		button4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { 
				inputTextField.setText(inputTextField.getText()+ "4");
			}
		});
		
		button5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { 
				inputTextField.setText(inputTextField.getText()+ "5");
			}
		});
		
		button6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { 
				inputTextField.setText(inputTextField.getText()+ "6");
			}
		});
		
		button7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { 
				inputTextField.setText(inputTextField.getText()+ "7");
			}
		});
		
		button8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { 
				inputTextField.setText(inputTextField.getText()+ "8");
			}
		});
		
		button9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { 
				inputTextField.setText(inputTextField.getText()+ "9");
			}
		});
		
		button0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { 
				inputTextField.setText(inputTextField.getText()+ "0");
			}
		});
		
		
		
		
		
	}
}
