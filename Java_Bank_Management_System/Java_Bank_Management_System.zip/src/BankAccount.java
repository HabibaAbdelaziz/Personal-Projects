
public class BankAccount
{
	private String bankNumber;
	private int pinCode;
	private double balance;
	private User bankUser;
	
	public void withdraw(double Amount) {
		balance = balance - Amount;
	}
	public void deposit(double Amount) {
		balance = balance + Amount;
	}
	
	public BankAccount(String bankNumber, int pinCode, double balance, User user) {
		this.bankNumber = bankNumber;
		this.pinCode = pinCode;
		this.balance = balance;
		bankUser = user;
		
	}

	public String getBankNumber() {
		return bankNumber;
	}

	public int getPinCode() {
		return pinCode;
	}

	public double getBalance() {
		return balance;
	}

	public User getUser() {
		return bankUser;
	}

	public void setBankNumber(String bankNumber) {
		this.bankNumber = bankNumber;
	}

	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	
	
	
	
	
}
